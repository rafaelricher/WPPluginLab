<?php
/*
Plugin Name: A1 Captura de dados
Description: Adiciona um formulário de contato personalizado com envio para link de whatsapp.
Version: 1.0
Author: Rafael Richer
Author URI: https://fabrica.tec.br/
*/

// Registrando um novo tipo de post 'formulario'
add_action('init', 'criar_post_type_formulario');
function criar_post_type_formulario() {
    $labels = array(
        'name' => 'Formulário',
        'singular_name' => 'Formulário',
        'menu_name' => 'Formulário',
        'all_items' => 'Todos os formulários',
        'add_new' => 'Adicionar novo',
        'add_new_item' => 'Adicionar novo formulário',
        'edit_item' => 'Editar formulário',
        'new_item' => 'Novo formulário',
        'view_item' => 'Ver formulário',
        'search_items' => 'Procurar formulários',
        'not_found' => 'Nenhum formulário encontrado',
        'not_found_in_trash' => 'Nenhum formulário encontrado na lixeira',
        'parent_item_colon' => '',
        'menu_icon' => 'dashicons-email-alt',
    );

    $args = array(
        'labels' => $labels,
        'description' => 'Formulário de contato',
        'public' => true,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'formulario'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title'),
    );

    register_post_type('formulario', $args);
}



// Manipula o envio do formulário
add_action('init', 'processar_formulario');
function processar_formulario() {
    if (isset($_POST['nome']) && isset($_POST['email']) && isset($_POST['whatsapp'])) {
        $nome = sanitize_text_field($_POST['nome']);
        $email = sanitize_email($_POST['email']);
        $whatsapp = sanitize_text_field($_POST['whatsapp']);
        
        // Armazenar no banco de dados
        $post_args = array(
            'post_title' => $nome,
            'post_type' => 'formulario',
            'post_status' => 'publish'
        );

        $post_id = wp_insert_post($post_args);

        if ($post_id) {
            update_post_meta($post_id, 'email', $email);
            update_post_meta($post_id, 'whatsapp', $whatsapp);
        }

        // Construir mensagem para o WhatsApp
        $mensagem_whatsapp = 'Olá, sou ' . $nome . ' e tenho interesse em participar'; // Mensagem com nome do remetente
        $whatsapp_link = 'https://api.whatsapp.com/send?phone=+5561996974332&text=' . urlencode($mensagem_whatsapp);
        wp_redirect($whatsapp_link);
        exit;
    }
}



// Adiciona mensagem de sucesso após o envio do formulário
add_action('wp_footer', 'mostrar_mensagem_formulario');
function mostrar_mensagem_formulario() {
    if (isset($_GET['enviado']) && $_GET['enviado'] == 'true') {
        echo '<p>Formulário enviado com sucesso!</p>';
    }
}

// Adiciona colunas personalizadas na lista de formulários no admin
add_filter('manage_formulario_posts_columns', 'adicionar_colunas_formulario');
function adicionar_colunas_formulario($columns) {
    $columns['nome'] = 'Nome';
    $columns['email'] = 'E-mail';
    $columns['whatsapp'] = 'WhatsApp';
    $columns['date'] = 'Data';

    return $columns;
}

// Exibe os valores das colunas personalizadas na lista de formulários no admin
add_action('manage_formulario_posts_custom_column', 'exibir_valores_colunas_formulario', 10, 2);
function exibir_valores_colunas_formulario($column, $post_id) {
    switch ($column) {
        case 'nome':
            echo get_the_title($post_id);
            break;
        case 'email':
            echo get_post_meta($post_id, 'email', true);
            break;
        case 'whatsapp':
            echo get_post_meta($post_id, 'whatsapp', true);
            break;
    }
}

// Torna as colunas personalizadas ordenáveis na lista de formulários no admin
add_filter('manage_edit-formulario_sortable_columns', 'tornar_colunas_ordenaveis_formulario');
function tornar_colunas_ordenaveis_formulario($columns) {
    $columns['nome'] = 'nome';
    $columns['email'] = 'email';
    $columns['whatsapp'] = 'whatsapp';

    return $columns;
}

// Ordena a lista de formulários no admin
add_action('pre_get_posts', 'ordenar_lista_formulario');
function ordenar_lista_formulario($query) {
    if (!is_admin() || !$query->is_main_query() || $query->get('post_type') != 'formulario') {
        return;
    }

    $orderby = $query->get('orderby');

    switch ($orderby) {
        case 'nome':
            $query->set('orderby', 'title');
            break;
        case 'email':
            $query->set('meta_key', 'email');
            $query->set('orderby', 'meta_value');
            break;
        case 'whatsapp':
            $query->set('meta_key', 'whatsapp');
            $query->set('orderby', 'meta_value');
            break;
    }
}
